# Wheel of Time Skills Module

A Foundry VTT module that modifies the Pathfinder 1e system for Wheel of Time campaigns.

## Features

- **Custom Skills**: Adds 19 new Wheel of Time-specific skills
- **Terminology Changes**: Changes "Armor Class" to "Defense"
- **Madness Tracking**: Adds a Madness field to character sheets
- **WoT Branding**: Integrates The Wheel of Time logo into character sheets
- **Skill Management**: Removes vanilla skills (Knowledge Arcana, Spellcraft)

## Installation

### Method 1: Manifest URL
1. Open Foundry VTT
2. Go to "Add-on Modules"
3. Click "Install Module"
4. Paste the manifest URL: `https://github.com/yourusername/wot-skills/releases/latest/download/module.json`
5. Click "Install"

### Method 2: Manual Installation
1. Download the latest release
2. Extract to `Data/modules/wot-skills`
3. Restart Foundry VTT
4. Enable the module in your world

## Requirements

- **Foundry VTT**: Version 11 or higher (tested on v12)
- **Game System**: Pathfinder 1e (pf1)

## Added Skills

### Standard Skills
- **Animal Empathy** (Charisma)
- **Composure** (Wisdom)
- **Forgery** (Intelligence)
- **Innuendo** (Wisdom)
- **Invert** (Intelligence)
- **Perception** (Wisdom)
- **Read Lips** (Intelligence)
- **Weavesight** (Intelligence)
- **Wilderness Lore** (Wisdom)

### Knowledge Skills
- **Knowledge (Aes Sedai)** (Intelligence)
- **Knowledge (Aiel)** (Intelligence)
- **Knowledge (Age of Legends)** (Intelligence)
- **Knowledge (Channeling)** (Intelligence)
- **Knowledge (Dreaming)** (Intelligence)
- **Knowledge (Blight)** (Intelligence)
- **Knowledge (Prophecy)** (Intelligence)
- **Knowledge (Saidin)** (Intelligence)
- **Knowledge (Saidar)** (Intelligence)
- **Knowledge (Shadow)** (Intelligence)

## Removed Skills

- Knowledge (Arcana)
- Spellcraft

## Configuration

Access module settings through:
1. Game Settings → Module Settings
2. Find "Wheel of Time Skills"
3. Configure options:
   - Enable/disable Madness field

## Usage

Once enabled, the module automatically:
- Adds custom skills to character sheets
- Replaces "Armor Class" with "Defense"
- Displays the WoT logo on character sheets
- Adds Madness tracking field

## Compatibility

This module is designed specifically for the Pathfinder 1e system and may not work with other game systems.

## Support

For issues, suggestions, or contributions:
- GitHub Issues: [Report a bug](https://github.com/yourusername/wot-skills/issues)
- Discussions: [Join the conversation](https://github.com/yourusername/wot-skills/discussions)

## License

This module is licensed under [LICENSE TYPE]. The Wheel of Time is a registered trademark of Robert Jordan's estate.

## Credits

- **Module Developer**: Your Name
- **The Wheel of Time**: Created by Robert Jordan
- **Logo**: The Wheel of Time trademark

## Changelog

### Version 1.0.0 (Initial Release)
- Added 19 custom WoT skills
- Changed AC to Defense terminology
- Added Madness tracking field
- Integrated WoT logo
- Removed vanilla skills (Knowledge Arcana, Spellcraft)

## Roadmap

Future features under consideration:
- Additional WoT-specific mechanics
- Channeling system integration
- Ter'angreal item templates
- Weave compendium