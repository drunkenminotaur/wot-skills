// scripts/wot-skills.js
Hooks.once('init', async function() {
  console.log('WoT Skills | Initializing Wheel of Time Skills Module');
  
  // Register module settings
  game.settings.register('wot-skills', 'enableMadnessField', {
    name: 'Enable Madness Field',
    hint: 'Add a Madness tracking field to character sheets',
    scope: 'world',
    config: true,
    type: Boolean,
    default: true
  });
});

Hooks.once('ready', async function() {
  console.log('WoT Skills | Module Ready');
  
  // Add custom skills to PF1 system
  if (game.system.id === 'pf1') {
    addWoTSkills();
    removeVanillaSkills();
  }
});

// Hook into character sheet rendering
Hooks.on('renderActorSheet', (app, html, data) => {
  if (game.system.id !== 'pf1') return;
  
  // Change "Armor Class" to "Defense"
  html.find('.armor-class, .ac-label').each(function() {
    const text = $(this).text();
    if (text.includes('Armor Class') || text.includes('AC')) {
      $(this).text(text.replace('Armor Class', 'Defense').replace('AC', 'Defense'));
    }
  });
  
  // Add Madness field if enabled
  if (game.settings.get('wot-skills', 'enableMadnessField')) {
    addMadnessField(html, data);
  }
  
  // Add WoT logo to character sheet
  addWoTLogo(html);
});

function addWoTSkills() {
  const customSkills = [
    { name: 'Animal Empathy', ability: 'cha', subSkills: [] },
    { name: 'Composure', ability: 'wis', subSkills: [] },
    { name: 'Forgery', ability: 'int', subSkills: [] },
    { name: 'Innuendo', ability: 'wis', subSkills: [] },
    { name: 'Invert', ability: 'int', subSkills: [] },
    { name: 'Knowledge', ability: 'int', subSkills: [
      'Aes Sedai',
      'Aiel',
      'Age of Legends',
      'Channeling',
      'Dreaming',
      'Blight',
      'Prophecy',
      'Saidin',
      'Saidar',
      'Shadow'
    ]},
    { name: 'Perception', ability: 'wis', subSkills: [] },
    { name: 'Read Lips', ability: 'int', subSkills: [] },
    { name: 'Weavesight', ability: 'int', subSkills: [] },
    { name: 'Wilderness Lore', ability: 'wis', subSkills: [] }
  ];
  
  console.log('WoT Skills | Adding custom skills:', customSkills);
  
  // Store custom skills in game settings for reference
  game.settings.register('wot-skills', 'customSkills', {
    scope: 'world',
    config: false,
    type: Object,
    default: customSkills
  });
}

function removeVanillaSkills() {
  const skillsToRemove = [
    'Knowledge (Arcana)',
    'Spellcraft'
  ];
  
  console.log('WoT Skills | Removing vanilla skills:', skillsToRemove);
  
  game.settings.register('wot-skills', 'removedSkills', {
    scope: 'world',
    config: false,
    type: Array,
    default: skillsToRemove
  });
}

function addMadnessField(html, data) {
  // Find appropriate location to insert madness field (near HP or other resources)
  const resourcesSection = html.find('.resources, .attributes');
  
  if (resourcesSection.length > 0) {
    const madnessHTML = `
      <div class="form-group wot-madness">
        <label>Madness</label>
        <input type="number" name="system.attributes.madness.value" 
               value="${data.actor.system.attributes?.madness?.value || 0}" 
               placeholder="0" />
        <span class="sep">/</span>
        <input type="number" name="system.attributes.madness.max" 
               value="${data.actor.system.attributes?.madness?.max || 10}" 
               placeholder="10" />
      </div>
    `;
    
    resourcesSection.append(madnessHTML);
  }
}

function addWoTLogo(html) {
  // Add logo to character sheet header
  const sheetHeader = html.find('.sheet-header, .window-title');
  
  if (sheetHeader.length > 0 && !html.find('.wot-logo').length) {
    const logoHTML = `
      <div class="wot-logo">
        <img src="modules/wot-skills/assets/WOTcalendarlogo.webp" 
             alt="The Wheel of Time" 
             title="The Wheel of Time" />
      </div>
    `;
    
    sheetHeader.prepend(logoHTML);
  }
}

// Export functions for potential use by other modules
export { addWoTSkills, removeVanillaSkills, addMadnessField, addWoTLogo };